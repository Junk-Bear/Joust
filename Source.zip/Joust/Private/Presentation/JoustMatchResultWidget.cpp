﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Presentation/JoustMatchResultWidget.h"
#include "Components/Border.h"
#include "Components/TextBlock.h"

void UJoustMatchResultWidget::SetMatchResult(const FJoustMatchResult& InMatchResult, bool bInLocalPlayerA)
{
	if (!IsValid(Border_MatchResultPanel) || !IsValid(Text_MatchOutcome) || !IsValid(Text_PlayerAScore) || !IsValid(Text_PlayerBScore))
		return;
	
	Border_MatchResultPanel->SetVisibility(ESlateVisibility::Visible);

	Text_MatchOutcome->SetText(GetLocalOutcomeText(InMatchResult.MatchOutcome, bInLocalPlayerA));

	Text_PlayerAScore->SetText(FText::AsNumber(InMatchResult.PlayerAScore));

	Text_PlayerBScore->SetText(FText::AsNumber(InMatchResult.PlayerBScore));
}

FText UJoustMatchResultWidget::GetLocalOutcomeText(EJoustMatchOutcome InMatchOutcome, bool bInLocalPlayerA) const
{
	switch (InMatchOutcome)
	{
	case EJoustMatchOutcome::PlayerAWin:
		if (bInLocalPlayerA)
		{
			return NSLOCTEXT("JoustMatchResultWidget", "PlayerAVictory", "VICTORY");
		}

		return NSLOCTEXT("JoustMatchResultWidget", "PlayerBDefeat", "DEFEAT");

	case EJoustMatchOutcome::PlayerBWin:
		if (bInLocalPlayerA)
		{
			return NSLOCTEXT("JoustMatchResultWidget", "PlayerADefeat", "DEFEAT");
		}

		return NSLOCTEXT("JoustMatchResultWidget", "PlayerBVictory", "VICTORY");

	case EJoustMatchOutcome::Draw:
		return NSLOCTEXT("JoustMatchResultWidget", "MatchDraw", "DRAW");

	default:
		return NSLOCTEXT("JoustMatchResultWidget", "MatchUndecided", "UNDECIDED");
	}
}
