﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Framework/JoustGameMode.h"
#include "Framework/JoustGameState.h"
#include "Framework/JoustPlayerState.h"
#include "Framework/JoustPlayerController.h"
#include "Framework/JoustPawn.h"
#include "Random/JoustDefaultRandomProvider.h"
#include "Match/JoustPhaseCoordinator.h"
#include "Match/JoustRoundCoordinator.h"
#include "Match/JoustMatchCoordinator.h"
#include "Rules/JoustRuleSetDataAsset.h"
#include "GameFramework/Controller.h"
#include "Framework/JoustAIController.h"
#include "Engine/World.h"
#include "Attack/JoustAttackTypeDataAsset.h"
#include "Prediction/JoustPredictionTypes.h"
#include "Presentation/JoustHUD.h"
#include "Result/JoustResultTypes.h"

AJoustGameMode::AJoustGameMode()
{
	GameStateClass = AJoustGameState::StaticClass();
	PlayerStateClass = AJoustPlayerState::StaticClass();
	PlayerControllerClass = AJoustPlayerController::StaticClass();
	DefaultPawnClass = AJoustPawn::StaticClass();
	HUDClass = AJoustHUD::StaticClass();
}

bool AJoustGameMode::AreParticipantsReady() const
{
	return PlayerAController.IsValid() && PlayerBController.IsValid();
}

bool AJoustGameMode::StartJoustMatch(AController* InRequestingController)
{
	if (!bMatchCoreReady ||
		!IsValid(MatchCoordinator) ||
		!PlayerAController.IsValid() ||
		MatchCoordinator->IsMatchActive() ||
		!IsValid(InRequestingController) ||
		InRequestingController != PlayerAController.Get())
		return false;

	const bool bPlayerBWasEmpty = !PlayerBController.IsValid();

	if (!PrepareMatchParticipants())
		return false;

	if (!MatchCoordinator->StartMatch())
	{
		if (bPlayerBWasEmpty)
		{
			AController* PlayerBControllerPtr = PlayerBController.Get();
			if (IsValid(PlayerBControllerPtr))
			{
				PlayerBControllerPtr->Destroy();
			}

			PlayerBController.Reset();
		}

		return false;
	}

	return true;
}

bool AJoustGameMode::SubmitPlayerStrategySelection(AJoustPlayerController* InRequestingController, FName InCardID)
{
	if (!bMatchCoreReady ||
		!IsValid(InRequestingController) ||
		InCardID.IsNone() ||
		!IsValid(RoundCoordinator) ||
		!IsValid(MatchCoordinator) ||
		!MatchCoordinator->IsMatchActive()
		)
		return false;

	const bool bPlayerA = InRequestingController == PlayerAController.Get();

	if (!bPlayerA && InRequestingController != PlayerBController.Get())
		return false;

	InRequestingController->SetSelectedStrategyCardID(InCardID);

	if (!RoundCoordinator->SubmitStrategySelection(bPlayerA, *InRequestingController))
	{
		InRequestingController->SetSelectedStrategyCardID(NAME_None);

		return false;
	}

	return true;
}

bool AJoustGameMode::SubmitPlayerStrategyBan(AJoustPlayerController* InRequestingController, FName InCardID)
{
	if (
		!bMatchCoreReady ||
		!IsValid(InRequestingController) ||
		InCardID.IsNone() ||
		!IsValid(RoundCoordinator) ||
		!IsValid(MatchCoordinator) ||
		!MatchCoordinator->IsMatchActive())
		return false;

	const bool bPlayerA = InRequestingController == PlayerAController.Get();
	const bool bPlayerB = InRequestingController == PlayerBController.Get();

	if (!bPlayerA && !bPlayerB)
		return false;

	InRequestingController->SetBannedStrategyCardID(InCardID);

	if (RoundCoordinator->SubmitStrategyBan(bPlayerA, *InRequestingController))
		return true;

	InRequestingController->SetBannedStrategyCardID(NAME_None);

	return false;

}

bool AJoustGameMode::SubmitPlayerAttack(AJoustPlayerController* InRequestingController, EJoustAttackType InAttackType, const FVector2D& InAttackPoint)
{
	if (!bMatchCoreReady || !IsValid(InRequestingController) || !IsValid(RoundCoordinator) || !IsValid(MatchCoordinator) || !MatchCoordinator->IsMatchActive())
		return false;

	const bool bPlayerA = InRequestingController == PlayerAController.Get();
	const bool bPlayerB = InRequestingController == PlayerBController.Get();

	if (!bPlayerA && !bPlayerB)
		return false;

	InRequestingController->SetAttackType(InAttackType);
	InRequestingController->SetAttackPoint(InAttackPoint);
	InRequestingController->ConfirmAttack();

	if (!RoundCoordinator->SubmitAttack(bPlayerA, *InRequestingController))
	{
		InRequestingController->ResetAttackInput();

		return false;
	}

	return true;
}

bool AJoustGameMode::SubmitPlayerDefense(AJoustPlayerController* InRequestingController, const FVector2D& InShieldPoint, bool bInParryAttempted, float InParryInputTime)
{
	if (
		!bMatchCoreReady ||
		!IsValid(InRequestingController) ||
		!IsValid(RuleSet) ||
		!IsValid(RoundCoordinator) ||
		!IsValid(MatchCoordinator) ||
		!MatchCoordinator->IsMatchActive() ||
		!FMath::IsFinite(InShieldPoint.X) ||
		!FMath::IsFinite(InShieldPoint.Y) ||
		(bInParryAttempted && !FMath::IsFinite(InParryInputTime))
		)
		return false;

	if (
		InShieldPoint.X < RuleSet->LanceBoxMin.X ||
		InShieldPoint.Y < RuleSet->LanceBoxMin.Y ||
		InShieldPoint.X > RuleSet->LanceBoxMax.X ||
		InShieldPoint.Y > RuleSet->LanceBoxMax.Y
		)
		return false;

	const bool bPlayerA = InRequestingController == PlayerAController.Get();
	const bool bPlayerB = InRequestingController == PlayerBController.Get();

	if (!bPlayerA && !bPlayerB)
		return false;

	InRequestingController->SetShieldPoint(InShieldPoint);

	if (bInParryAttempted && !InRequestingController->IsParryAttempted())
	{
		InRequestingController->SetParryAttempt(InParryInputTime);
	}

	return RoundCoordinator->SubmitDefense(bPlayerA, *InRequestingController);
}

void AJoustGameMode::InitGameState()
{
	Super::InitGameState();

	bMatchCoreReady = InitializeMatchCore();
}

void AJoustGameMode::PostLogin(APlayerController* InNewPlayer)
{
	Super::PostLogin(InNewPlayer);

	if (!bMatchCoreReady || !IsValid(InNewPlayer))
		return;

	AJoustPlayerController* JoustPlayerControllerPtr = Cast<AJoustPlayerController>(InNewPlayer);
	if (!IsValid(JoustPlayerControllerPtr))
		return;

	if (IsValid(MatchCoordinator) && MatchCoordinator->IsMatchActive())
	{
		JoustPlayerControllerPtr->StartSpectatingOnly();

		return;
	}

	if (!PlayerAController.IsValid())
	{
		PlayerAController = JoustPlayerControllerPtr;

		return;
	}

	if (!PlayerBController.IsValid())
	{
		PlayerBController = JoustPlayerControllerPtr;

		return;
	}

	JoustPlayerControllerPtr->StartSpectatingOnly();
}

bool AJoustGameMode::InitializeMatchCore()
{
	if (!IsValid(RuleSet) || !IsValid(GetWorld()))
		return false;

	RandomProvider = NewObject<UJoustDefaultRandomProvider>(this);

	PhaseCoordinator = NewObject<UJoustPhaseCoordinator>(this);

	RoundCoordinator = NewObject<UJoustRoundCoordinator>(this);

	MatchCoordinator = NewObject<UJoustMatchCoordinator>(this);

	AJoustGameState* JoustGameStatePtr = GetGameState<AJoustGameState>();
	if (!IsValid(JoustGameStatePtr))
		return false;

	if (!IsValid(RandomProvider) || !IsValid(PhaseCoordinator) || !IsValid(RoundCoordinator) || !IsValid(MatchCoordinator))
		return false;

	JoustGameStatePtr->SetRuleSet(RuleSet.Get());

	RandomProvider->Initialize(InitialRandomSeed);

	PhaseCoordinator->Initialize(GetWorld());

	RoundCoordinator->Initialize(PhaseCoordinator, RuleSet.Get(), *RandomProvider);

	RoundCoordinator->OnPhaseStarted().AddUObject(this, &AJoustGameMode::HandleRoundPhaseStarted);

	RoundCoordinator->OnStrategyBansCompleted().AddUObject(this, &AJoustGameMode::HandleStrategyBansCompleted);

	RoundCoordinator->OnRoundResult().AddUObject(this, &AJoustGameMode::HandleRoundResult);

	MatchCoordinator->Initialize(RoundCoordinator, PhaseCoordinator, RuleSet.Get());

	MatchCoordinator->OnMatchResult().AddUObject(this, &AJoustGameMode::HandleMatchResult);

	RoundCoordinator->SetGameState(JoustGameStatePtr);

	MatchCoordinator->SetGameState(JoustGameStatePtr);

	return true;
}

bool AJoustGameMode::PrepareMatchParticipants()
{
	if (!bMatchCoreReady || !IsValid(RoundCoordinator) || !IsValid(GetWorld()))
		return false;

	AJoustGameState* GameStatePtr = GetGameState<AJoustGameState>();
	if (!IsValid(GameStatePtr))
		return false;

	AController* PlayerAControllerPtr = PlayerAController.Get();
	if (!IsValid(PlayerAControllerPtr))
		return false;

	AController* PlayerBControllerPtr = PlayerBController.Get();

	AJoustAIController* SpawnedAIControllerPtr = nullptr;

	if (!IsValid(PlayerBControllerPtr))
	{
		FActorSpawnParameters SpawnParameters;

		SpawnParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

		SpawnedAIControllerPtr = GetWorld()->SpawnActor<AJoustAIController>(
			AJoustAIController::StaticClass(),
			FVector::ZeroVector,
			FRotator::ZeroRotator,
			SpawnParameters);

		if (!IsValid(SpawnedAIControllerPtr))
			return false;

		PlayerBControllerPtr = SpawnedAIControllerPtr;
	}

	AJoustPlayerState* PlayerAStatePtr = PlayerAControllerPtr->GetPlayerState<AJoustPlayerState>();
	AJoustPlayerState* PlayerBStatePtr = PlayerBControllerPtr->GetPlayerState<AJoustPlayerState>();
	if (!IsValid(PlayerAStatePtr) || !IsValid(PlayerBStatePtr) || PlayerAStatePtr == PlayerBStatePtr)
	{
		if (IsValid(SpawnedAIControllerPtr))
		{
			SpawnedAIControllerPtr->Destroy();
		}

		return false;
	}

	if (!RoundCoordinator->ResetMatchState())
	{
		if (IsValid(SpawnedAIControllerPtr))
		{
			SpawnedAIControllerPtr->Destroy();
		}

		return false;
	}

	PlayerAStatePtr->InitializeStats(PlayerABaseStats);
	PlayerBStatePtr->InitializeStats(PlayerBBaseStats);

	PlayerAStatePtr->ResetMatchState();
	PlayerBStatePtr->ResetMatchState();

	if (!ResetParticipantInput(PlayerAControllerPtr) || !ResetParticipantInput(PlayerBControllerPtr))
	{
		if (IsValid(SpawnedAIControllerPtr))
		{
			SpawnedAIControllerPtr->Destroy();
		}

		return false;
	}

	if (!RoundCoordinator->SetPlayerStates(PlayerAStatePtr, PlayerBStatePtr))
	{
		if (IsValid(SpawnedAIControllerPtr))
		{
			SpawnedAIControllerPtr->Destroy();
		}

		return false;
	}

	GameStatePtr->SetParticipantStates(PlayerAStatePtr, PlayerBStatePtr);

	if (IsValid(SpawnedAIControllerPtr))
	{
		PlayerBController = SpawnedAIControllerPtr;
	}

	return true;
}

bool AJoustGameMode::ResetParticipantInput(AController* InController)
{
	AJoustPlayerController* PlayerControllerPtr = Cast<AJoustPlayerController>(InController);
	if (IsValid(PlayerControllerPtr))
	{
		PlayerControllerPtr->ResetStrategyInput();
		PlayerControllerPtr->ResetAttackInput();
		PlayerControllerPtr->ResetDefenseInput();

		return true;
	}

	AJoustAIController* AIControllerPtr = Cast<AJoustAIController>(InController);
	if (IsValid(AIControllerPtr))
	{
		AIControllerPtr->ResetStrategyInput();
		AIControllerPtr->ResetAttackInput();
		AIControllerPtr->ResetDefenseInput();

		return true;
	}

	return false;
}

void AJoustGameMode::HandleRoundPhaseStarted(EJoustPhase InPhase)
{
	if (!IsValid(RoundCoordinator))
		return;

	AController* PlayerControllerPtrs[] = { PlayerAController.Get(), PlayerBController.Get() };

	for (AController* Item : PlayerControllerPtrs)
	{
		AJoustPlayerController* PlayerControllerPtr = Cast<AJoustPlayerController>(Item);
		if (!IsValid(PlayerControllerPtr))
			continue;

		switch (InPhase)
		{
		case EJoustPhase::Strategy:
			PlayerControllerPtr->ResetStrategyInput();

			break;

		case EJoustPhase::Attack:
			PlayerControllerPtr->ResetAttackInput();

			break;

		case EJoustPhase::Defense:
			PlayerControllerPtr->ResetDefenseInput();

			break;

		default:
			break;
		}
	}

	AJoustAIController* PlayerAAIControllerPtr = Cast<AJoustAIController>(PlayerAController.Get());
	if (IsValid(PlayerAAIControllerPtr))
	{
		switch (InPhase)
		{
		case EJoustPhase::Strategy:
			SubmitAIStrategy(true, *PlayerAAIControllerPtr);
			break;

		case EJoustPhase::Attack:
			SubmitAIAttack(true, *PlayerAAIControllerPtr);
			break;

		case EJoustPhase::Defense:
			SubmitAIDefense(true, *PlayerAAIControllerPtr);
			break;

		default:
			break;
		}
	}

	AJoustAIController* PlayerBAIControllerPtr = Cast<AJoustAIController>(PlayerBController.Get());
	if (IsValid(PlayerBAIControllerPtr))
	{
		switch (InPhase)
		{
		case EJoustPhase::Strategy:
			SubmitAIStrategy(false, *PlayerBAIControllerPtr);
			break;

		case EJoustPhase::Attack:
			SubmitAIAttack(false, *PlayerBAIControllerPtr);
			break;

		case EJoustPhase::Defense:
			SubmitAIDefense(false, *PlayerBAIControllerPtr);
			break;

		default:
			break;
		}
	}
}

void AJoustGameMode::HandleStrategyBansCompleted()
{
	AJoustAIController* PlayerAAIControllerPtr = Cast<AJoustAIController>(PlayerAController.Get());
	if (IsValid(PlayerAAIControllerPtr))
	{
		SubmitAIStrategySelection(true, *PlayerAAIControllerPtr);
	}

	AJoustAIController* PlayerBAIControllerPtr = Cast<AJoustAIController>(PlayerBController.Get());
	if (IsValid(PlayerBAIControllerPtr))
	{
		SubmitAIStrategySelection(false, *PlayerBAIControllerPtr);
	}
}

bool AJoustGameMode::SubmitAIStrategy(bool bInPlayerA, AJoustAIController& InOutAIController)
{
	if (!IsValid(RoundCoordinator) || !IsValid(RandomProvider))
		return false;

	AJoustGameState* JoustGameStatePtr = GetGameState<AJoustGameState>();
	if (!IsValid(JoustGameStatePtr))
		return false;

	InOutAIController.ResetStrategyInput();

	const TArray<FName>& PublicCardsRef = JoustGameStatePtr->GetPublicStrategyCardIDs();

	if (PublicCardsRef.IsEmpty())
		return false;

	InOutAIController.SetBannedStrategyCardID(PublicCardsRef[RandomProvider->GetRandom(0, PublicCardsRef.Num() - 1)]);

	if (RoundCoordinator->SubmitStrategyBan(bInPlayerA, InOutAIController))
		return true;

	return SubmitAIStrategySelection(bInPlayerA, InOutAIController);
}

bool AJoustGameMode::SubmitAIStrategySelection(bool bInPlayerA, AJoustAIController& InOutAIController)
{
	if (!IsValid(RoundCoordinator) || !IsValid(RandomProvider))
		return false;

	AJoustGameState* JoustGameStatePtr = GetGameState<AJoustGameState>();
	if (!IsValid(JoustGameStatePtr))
		return false;

	const FName BannedCardID = bInPlayerA ? JoustGameStatePtr->GetBannedCardIDForPlayerA() : JoustGameStatePtr->GetBannedCardIDForPlayerB();

	TArray<FName> SelectableCards;

	for (FName Item : JoustGameStatePtr->GetPublicStrategyCardIDs())
	{
		if (!Item.IsNone() && Item != BannedCardID)
		{
			SelectableCards.Add(Item);
		}
	}

	if (SelectableCards.IsEmpty())
		return false;

	InOutAIController.SetSelectedStrategyCardID(SelectableCards[RandomProvider->GetRandom(0, SelectableCards.Num() - 1)]);

	return RoundCoordinator->SubmitStrategySelection(bInPlayerA, InOutAIController);
}

bool AJoustGameMode::SubmitAIAttack(bool bInPlayerA, AJoustAIController& InOutAIController)
{
	if (!IsValid(RoundCoordinator) || !IsValid(RuleSet) || !IsValid(RandomProvider))
		return false;

	AJoustPlayerState* PlayerStatePtr = InOutAIController.GetPlayerState<AJoustPlayerState>();
	if (!IsValid(PlayerStatePtr))
		return false;

	TArray<EJoustAttackType> AvailableAttackTypes;

	for (const TPair<EJoustAttackType, TObjectPtr<UJoustAttackTypeDataAsset>>& Item : RuleSet->AttackTypeSettings)
	{
		if (!IsValid(Item.Value))
			continue;

		const int32 RemainingUses = PlayerStatePtr->GetRemainingAttackUses(Item.Key);

		if (RemainingUses == INDEX_NONE || RemainingUses > 0)
		{
			AvailableAttackTypes.Add(Item.Key);
		}
	}

	if (AvailableAttackTypes.IsEmpty())
		return false;

	InOutAIController.ResetAttackInput();

	InOutAIController.SetAttackType(AvailableAttackTypes[RandomProvider->GetRandom(0, AvailableAttackTypes.Num() - 1)]);

	InOutAIController.SetAttackPoint(RandomProvider->GetRandom(RuleSet->LanceBoxMin, RuleSet->LanceBoxMax));

	InOutAIController.ConfirmAttack();

	return RoundCoordinator->SubmitAttack(bInPlayerA, InOutAIController);
}

bool AJoustGameMode::SubmitAIDefense(bool bInPlayerA, AJoustAIController& InOutAIController)
{
	if (!IsValid(RoundCoordinator) || !IsValid(RandomProvider))
	{
		return false;
	}

	FJoustPredictionState PredictionState;

	if (!RoundCoordinator->GetDefensePredictionState(bInPlayerA, PredictionState))
		return false;

	const int32 CircleIdx = RandomProvider->GetRandom(0, PredictionState.DisplayCircles.Num() - 1);

	InOutAIController.ResetDefenseInput();

	InOutAIController.SetShieldPoint(PredictionState.DisplayCircles[CircleIdx].Center);

	return RoundCoordinator->SubmitDefense(bInPlayerA, InOutAIController);
}

void AJoustGameMode::HandleRoundResult(const FJoustRoundResult& InRoundResult)
{
	if (InRoundResult.RoundNumber <= 0)
		return;

	UWorld* WorldPtr = GetWorld();
	if (!IsValid(WorldPtr))
		return;

	WorldPtr->GetTimerManager().ClearTimer(RoundResultCompletionTimerHandle);

	WorldPtr->GetTimerManager().SetTimer(
		RoundResultCompletionTimerHandle,
		this,
		&AJoustGameMode::CompleteRoundResultPresentation,
		FMath::Max(0.1f, RoundResultDisplayDuration),
		false);
}

void AJoustGameMode::HandleMatchResult(const FJoustMatchResult & InMatchResult)
{
	if (InMatchResult.MatchOutcome == EJoustMatchOutcome::Undecided)
		return;

	UWorld* WorldPtr = GetWorld();
	if (!IsValid(WorldPtr))
		return;

	WorldPtr->GetTimerManager().ClearTimer(MatchResultCompletionTimerHandle);

	WorldPtr->GetTimerManager().SetTimer(
		MatchResultCompletionTimerHandle,
		this,
		&AJoustGameMode::CompleteMatchResultPresentation,
		FMath::Max(0.1f, MatchResultDisplayDuration),
		false);
}

void AJoustGameMode::CompleteRoundResultPresentation()
{
	if (!IsValid(RoundCoordinator))
		return;

	RoundCoordinator->CompleteRoundResultPhase();
}

void AJoustGameMode::CompleteMatchResultPresentation()
{
	if (!IsValid(MatchCoordinator))
		return;

	MatchCoordinator->CompleteMatchResultPhase();
}
